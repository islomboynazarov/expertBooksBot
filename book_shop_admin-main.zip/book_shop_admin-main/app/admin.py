from django.contrib import admin

from app.models import Book, User, Category, FAQ, Contact, Cart, Order, BookFile, Audios


# Register your models here.
@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    exclude = ('image_id',)

@admin.register(BookFile)
class BookFileAdmin(admin.ModelAdmin):
    list_display = ('book', 'file')


@admin.register(Audios)
class BookAudioAdmin(admin.ModelAdmin):
    list_display = ('book', 'file')


admin.site.register(User)
admin.site.register(Category)
admin.site.register(FAQ)
admin.site.register(Contact)
admin.site.register(Cart)
admin.site.register(Order)
