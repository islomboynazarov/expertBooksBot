from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Book, Audios, BookFile
import os
import zipfile
import shutil


@receiver(post_save, sender=Book)
def create_profile(sender, instance, created, **kwargs):
    extract_file = r"C:\Users\obidj\PycharmProjects\book_shop_admin\media\books\file_id\{0}".format(instance.id)
    extract_audio = r"C:\Users\obidj\PycharmProjects\book_shop_admin\media\books\audio_id\{0}".format(instance.id)
    dirs = [extract_file, extract_audio]

    for dir in dirs:
        if not os.path.exists(dir):
            os.makedirs(dir)
        else:
            if os.listdir(dir):
                shutil.rmtree(dir)
                os.makedirs(dir)

    if instance.files:
        with zipfile.ZipFile(instance.files.path) as zip_ref:
            zip_ref.extractall(extract_file)

        for filename in os.listdir(extract_file):
            BookFile.objects.create(file=r'books\file_id\{0}\{1}'.format(instance.id, filename), book_id=instance.id)
    else:
        shutil.rmtree(extract_file)
        BookFile.objects.filter(book_id=instance.id).delete()

    if instance.audio:
        with zipfile.ZipFile(instance.audio.path) as zip_ref:
            zip_ref.extractall(extract_audio)

        for filename in os.listdir(extract_audio):
            Audios.objects.create(file=r'books\audio_id\{0}\{1}'.format(instance.id, filename), book_id=instance.id)
    else:
        shutil.rmtree(extract_audio)
        Audios.objects.filter(book_id=instance.id).delete()
