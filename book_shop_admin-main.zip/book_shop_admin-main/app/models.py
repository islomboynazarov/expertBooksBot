import zipfile
import os
from django.db import models


# Create your models here.


class User(models.Model):
    tg_id = models.IntegerField(primary_key=True)
    full_name = models.CharField(max_length=255)
    username = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.full_name

    class Meta:
        db_table = 'tg_users'
        verbose_name = 'User'
        verbose_name_plural = 'Users'


class Category(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'categories'
        verbose_name = 'Category'
        verbose_name_plural = 'Categories'


class Book(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    price = models.IntegerField()
    image = models.ImageField(upload_to='books/', null=True, blank=True)
    image_id = models.CharField(max_length=255, null=True, blank=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    files = models.FileField(upload_to='books/files', null=True, blank=True)
    audio = models.FileField(upload_to='books/audio', null=True, blank=True)

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'books'
        verbose_name = 'Book'
        verbose_name_plural = 'Books'


class Audios(models.Model):
    file = models.CharField(max_length=500, null=True, blank=True)
    file_id = models.CharField(max_length=255, null=True, blank=True)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)

    def __str__(self):
        return self.book.title

    class Meta:
        db_table = 'audio'
        verbose_name = 'Audio'
        verbose_name_plural = 'Audio'


class BookFile(models.Model):
    file = models.CharField(max_length=500, null=True, blank=True)
    file_id = models.CharField(max_length=500, null=True, blank=True)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)

    def __str__(self):
        return self.book.title

    class Meta:
        db_table = 'book_files'
        verbose_name = 'Book File'
        verbose_name_plural = 'Book Files'


class Order(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user.full_name} -> {self.book.title}"

    class Meta:
        db_table = 'orders'
        verbose_name = 'Order'
        verbose_name_plural = 'Orders'


class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user.full_name} -> {self.book.title}"

    class Meta:
        db_table = 'carts'
        verbose_name = 'Cart'
        verbose_name_plural = 'Carts'


class FAQ(models.Model):
    question = models.TextField()
    answer = models.TextField()

    def __str__(self):
        return self.question

    class Meta:
        db_table = 'faq'
        verbose_name = 'FAQ'
        verbose_name_plural = 'FAQ'


class Contact(models.Model):
    name = models.CharField(max_length=255)
    data = models.TextField()

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'contacts'
        verbose_name = 'Contact'
        verbose_name_plural = 'Contacts'
