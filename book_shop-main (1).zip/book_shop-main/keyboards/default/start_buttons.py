from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

first_buttons = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
first_buttons.insert(KeyboardButton("📚 Books"))
first_buttons.insert(KeyboardButton("📚 My Books"))
first_buttons.insert(KeyboardButton("🛒 Cart"))
first_buttons.insert(KeyboardButton("ℹ️ Contacts"))
first_buttons.insert(KeyboardButton("📎 FAQ"))
