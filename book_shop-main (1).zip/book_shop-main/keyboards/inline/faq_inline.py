from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def see_answer_btn(ques_id):
    res = InlineKeyboardMarkup()
    res.add(InlineKeyboardButton('👁 View answer', callback_data=f"answer-{ques_id}"))
    return res


def next_question_btn(ques_id, indices, btn=False):
    button = InlineKeyboardButton("More questions ➡️", callback_data=f"next-{ques_id}-{indices}")
    if btn:
        return button
    res = InlineKeyboardMarkup()
    res.add(button)
    return res


def prev_question_btn(ques_id, indices, btn=False):
    button = InlineKeyboardButton("Previous question ⬅️", callback_data=f"prev-{ques_id}-{indices}")
    if btn:
        return button
    res = InlineKeyboardMarkup()
    res.add(button)
    return res


def hide_answer_btn(msg_id, ques_id):
    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("Hide", callback_data=f"hide-{msg_id}-{ques_id}"))
    return markup
