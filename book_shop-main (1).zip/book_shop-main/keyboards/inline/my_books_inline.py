from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def get_my_books(books):
    keyboard = InlineKeyboardMarkup(row_width=5)
    for i, book in enumerate(books, start=1):
        keyboard.insert(InlineKeyboardButton(f'{i}', callback_data=f"mybook-{book[1]}"))
    return keyboard


def next_my_book(book_id):
    return InlineKeyboardButton(f'More Books ➡️', callback_data=f'mybnext-{book_id}')


def prev_my_book(book_id):
    return InlineKeyboardButton(f'Previous Books ⬅️', callback_data=f'mybprev-{book_id}')


def read_or_listen_book(book_id):
    res = InlineKeyboardMarkup(row_width=2)
    res.insert(InlineKeyboardButton('📖 Read', callback_data=f'read-{book_id}'))
    res.insert(InlineKeyboardButton('🎧 Listen', callback_data=f'listen-{book_id}'))
    return res
