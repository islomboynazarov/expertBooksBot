from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

text = "⬅️ Back"

main_menu = InlineKeyboardButton(text, callback_data='main_menu')
back_cat = InlineKeyboardButton(text, callback_data='choose_cat')
my_books = InlineKeyboardButton('📚 My Books', callback_data='listmybooks')
my_cart = InlineKeyboardButton('🛒 Back to Cart', callback_data='backcart')


def main_menu_faq(quantity):
    return InlineKeyboardButton(text, callback_data=f'main_menu_faq-{quantity}')


def get_cat(cat_id):
    return InlineKeyboardButton(text, callback_data=f'cat-{cat_id}')


def get_book(book_id, num):
    return InlineKeyboardButton(text, callback_data=f'backmybook-{book_id}-{num}')
