from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from loader import db


def get_cart_items(items_list):
    res = InlineKeyboardMarkup(row_width=5)
    for i, cat in enumerate(items_list, start=1):
        res.insert(InlineKeyboardButton(f"{i}", callback_data=f"cartitem-{cat[1]}-{cat[0]}"))
    return res


def del_item(cart_item_id):
    res = InlineKeyboardMarkup(row_width=2)
    res.add(InlineKeyboardButton('❌ Delete from Cart', callback_data=f'deleteitem-{cart_item_id}'))
    return res
