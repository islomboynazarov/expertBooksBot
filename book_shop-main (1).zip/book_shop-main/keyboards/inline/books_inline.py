from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from loader import db


def get_categories(cat_list):
    res = InlineKeyboardMarkup(row_width=2)
    for cat in cat_list:
        res.add(InlineKeyboardButton(f"{cat[1]}", callback_data=f"cat-{cat[0]}"))
    return res


def get_books(books, user_id):
    keyboard = InlineKeyboardMarkup(row_width=5)
    book_ids = [order[1] for order in db.select_my_orders(user_id=user_id)]
    orders = [order[1] for order in db.select_cart_items(user_id=user_id)]
    for i, book in enumerate(books, start=1):
        if book[0] in book_ids:
            keyboard.insert(InlineKeyboardButton(f'{i}', callback_data=f"mybook2-{book[0]}"))
        elif book[0] in orders:
            keyboard.insert(InlineKeyboardButton(f'{i}', callback_data=f'cartbook-{book[0]}'))
        else:
            keyboard.insert(InlineKeyboardButton(f"{i}", callback_data=f"book-{book[0]}"))
    return keyboard


def next_book(book_id, cat_id):
    return InlineKeyboardButton(f'More Books ➡️', callback_data=f'bnext-{cat_id}-{book_id}')


def prev_book(book_id, cat_id):
    return InlineKeyboardButton(f'Previous Books ⬅️', callback_data=f'bprev-{cat_id}-{book_id}')
