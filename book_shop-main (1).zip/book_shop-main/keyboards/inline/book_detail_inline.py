from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def buy_buttons(book_id):
    keyboard = InlineKeyboardMarkup(row_width=2)
    keyboard.insert(InlineKeyboardButton('💵 Buy Now', callback_data=f'buynow-{book_id}'))
    keyboard.insert(InlineKeyboardButton('🛒 Add to Cart', callback_data=f'addtocart-{book_id}'))
    return keyboard
