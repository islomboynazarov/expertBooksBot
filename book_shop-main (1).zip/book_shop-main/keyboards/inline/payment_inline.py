from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def buy_from_cart(list_book_id):
    return InlineKeyboardButton('💳 Checkout', callback_data=f'bc-{list_book_id}')
