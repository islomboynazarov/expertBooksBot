from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup

from keyboards.default.start_buttons import first_buttons
from keyboards.inline.back_buttons import main_menu
from keyboards.inline.my_books_inline import get_my_books, next_my_book, prev_my_book
from loader import dp, db


# Echo bot
@dp.message_handler(text="📚 My Books", state="*")
@dp.callback_query_handler(lambda query: query.data.startswith("listmybooks"))
async def bot_echo(message: types.Message, state: FSMContext):
    await state.finish()
    user_id = message.from_user.id
    if isinstance(message, types.CallbackQuery):
        await message.message.delete()
        message = message.message
    books = db.select_my_orders(user_id=user_id)
    msg = f"Your books:\n\n"
    if books:
        for i, book in enumerate(books[:10], start=1):
            book = db.select_book(id=book[1])
            msg += f"{i}. {book[1]}\n"
        btns = get_my_books(books[:10])
        if len(books) > 10:
            btns.row(next_my_book(10))
        btns.row(main_menu)
        await message.answer(msg, parse_mode="HTML", reply_markup=btns)
    else:
        btn = InlineKeyboardMarkup()
        btn.row(main_menu)
        await message.answer("You don't have any books purchased yet 😕", reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("mybnext"))
async def bot_echo(callback: types.CallbackQuery):
    book_id = int(callback.data.split('-')[1])
    books = db.select_my_orders(user_id=callback.from_user.id)
    msg = f"Your books:\n\n"
    for i, book in enumerate(books[book_id:book_id + 10], start=1):
        book = db.select_book(id=book[1])
        msg += f"{i}. {book[1]}\n"
    btns = get_my_books(books[book_id:book_id + 10])
    next_prev = [prev_my_book(book_id - 10)]
    if len(books[book_id:]) > 10:
        next_prev.append(next_my_book(book_id + 10))
    btns.row(*next_prev)
    btns.row(main_menu)
    await callback.message.edit_text(msg, parse_mode="HTML", reply_markup=btns)


@dp.callback_query_handler(lambda query: query.data.startswith("mybprev"))
async def bot_echo(callback: types.CallbackQuery):
    book_id = int(callback.data.split('-')[1])
    books = db.select_my_orders(user_id=callback.from_user.id)
    msg = f"Your books:\n\n"
    for i, book in enumerate(books[book_id:book_id + 10], start=1):
        book = db.select_book(id=book[1])
        msg += f"{i}. {book[1]}\n"
    btns = get_my_books(books[book_id:book_id + 10])
    next_prev = []
    if len(books[:book_id]) >= 10:
        next_prev.append(prev_my_book(book_id - 10))
    next_prev.append(next_my_book(book_id + 10))
    btns.row(*next_prev)
    btns.row(main_menu)
    await callback.message.edit_text(msg, parse_mode="HTML", reply_markup=btns)
