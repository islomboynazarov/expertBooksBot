from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType

from keyboards.default.start_buttons import first_buttons
from loader import dp, db, bot


@dp.message_handler(CommandStart(), state="*", content_types=ContentType.ANY)
@dp.callback_query_handler(lambda query: query.data.startswith('main_menu'), state='*')
async def bot_start(message: types.Message, state: FSMContext):
    await state.finish()
    print(message.chat)
    user = message.from_user
    if isinstance(message, types.CallbackQuery):
        await message.message.delete()
        print(message.data)
        if message.data.startswith('main_menu_faq'):
            quantity = message.data.split('-')[1]
            if quantity != '0':
                for i in range(1, int(quantity) + 1):
                    await bot.delete_message(message.message.chat.id, message.message.message_id - i)
        message = message.message
    users = [i[2] for i in db.select_all_users()]
    if user.id not in users:
        db.create_user(user.full_name, user.username, user.id)
    await message.answer(f'Hello {user.first_name}, welcome to Book Shop!', reply_markup=first_buttons)
