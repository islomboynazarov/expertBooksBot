from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup

from keyboards.default.start_buttons import first_buttons
from keyboards.inline.back_buttons import main_menu
from loader import dp, db, bot


# Echo bot
@dp.message_handler(text="ℹ️ Contacts", state="*")
async def bot_echo(message: types.Message, state: FSMContext):
    await state.finish()
    contacts = db.select_all_contacts()
    btn = InlineKeyboardMarkup()
    btn.row(main_menu)
    if contacts:
        msg = ""
        for contact in contacts:
            msg += f"{contact[1]}: <b>{contact[2]}</b>\n"
        await message.answer(msg, parse_mode="HTML", reply_markup=btn)
    else:
        await message.answer("At the moment we don't have contacts.", reply_markup=btn)
