from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup

from keyboards.default.start_buttons import first_buttons
from keyboards.inline.back_buttons import get_book
from keyboards.inline.book_detail_inline import buy_buttons
from keyboards.inline.my_books_inline import read_or_listen_book
from loader import dp, db, bot
from utils.get_photo import get_book_file, get_book_audio, get_input_file


@dp.callback_query_handler(lambda query: query.data.startswith("read"))
async def bot_echo(callback: types.CallbackQuery):
    book_id = callback.data.split('-')[1]
    book_files = db.select_book_files(book_id=book_id)
    await bot.delete_message(callback.message.chat.id, callback.message.message_id)
    btn = InlineKeyboardMarkup()
    btn.row(get_book(book_id, len(book_files)))
    if book_files:
        await bot.send_message(callback.message.chat.id,
                               'To read this book, we suggest you download it as a file\nPlease wait a little while we send you the file •••')
        for book in book_files:
            if book[1]:
                file = await get_book_file(book[1], book[2])
                db.update_file(file, book[0])
                try:
                    await bot.send_document(callback.message.chat.id, file)
                except Exception as e:
                    file = await get_input_file(book[1])
                    file_id = await bot.send_document(callback.message.chat.id, file)
                    db.update_file(file_id, book[0])
        await bot.send_message(callback.message.chat.id, 'Back to book description', reply_markup=btn)
    else:
        await bot.send_message(callback.message.chat.id, "This book doesn't have any files to read", reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("listen"))
async def bot_echo(callback: types.CallbackQuery):
    book_id = callback.data.split('-')[1]
    book_files = db.select_book_audio(book_id=book_id)
    await bot.delete_message(callback.message.chat.id, callback.message.message_id)
    btn = types.InlineKeyboardMarkup()
    btn.row(get_book(book_id, len(book_files)))
    if book_files:
        await bot.send_message(callback.message.chat.id,
                               'To listen this book, we suggest you download it as a audio file\nPlease wait a little while we send you the audio file •••')
        for book in book_files:
            if book[1]:
                file = await get_book_audio(book[1], book[2])
                db.update_audio(file, book[0])
                print(file, 777)
                try:
                    await bot.send_document(callback.message.chat.id, file)
                except Exception as e:
                    file = await get_input_file(book[1])
                    file_id = await bot.send_document(callback.message.chat.id, file)
                    db.update_audio(file_id, book[0])
        await bot.send_message(callback.message.chat.id, 'Back to book description', reply_markup=btn)
    else:
        await bot.send_message(callback.message.chat.id, "This book doesn't have any audio files to listen",
                               reply_markup=btn)
