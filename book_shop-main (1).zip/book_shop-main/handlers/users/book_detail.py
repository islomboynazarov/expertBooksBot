from aiogram import types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from keyboards.inline.back_buttons import get_cat, back_cat, my_books, my_cart
from keyboards.inline.book_detail_inline import buy_buttons
from keyboards.inline.cart_inline import del_item
from keyboards.inline.my_books_inline import read_or_listen_book
from loader import dp, db, bot
from utils.get_photo import get_book_photo, get_book_file, get_input_file


@dp.callback_query_handler(lambda query: query.data.startswith("book-"))
@dp.callback_query_handler(lambda query: query.data.startswith("cartitem-"))
async def bot_echo(callback: types.CallbackQuery):
    book_id = callback.data.split("-")[1]
    book = db.select_book(id=book_id)
    btn = buy_buttons(book_id)
    book_files = db.select_book_audio(book_id=book_id)
    if book:
        image = None
        title = book[1]
        author = book[2]
        description = book[3]
        price = book[4]
        if book[5]:
            image = await get_book_photo(book[5], book[7])
            db.update_book(image, book[0])
        btn.row(get_cat(book[6]))
        if book_files:
            t = '\n<b>🎧 AUDIO BOOK INCLUDED</b>'
        else:
            t = ''
        msg = f"<b>{title}</b>{t}\n\nAuthor: <b>{author}</b>\nAbout book: <em>{description}</em>\nPrice: <b>{price} so'm</b>"
        await bot.delete_message(callback.message.chat.id, callback.message.message_id)
        if callback.data.startswith('cartitem'):
            cartitem_id = callback.data.split('-')[2]
            btn = del_item(cartitem_id)
            btn.row(my_cart)
        if image:
            try:
                await bot.send_photo(callback.message.chat.id, image, caption=msg, parse_mode="HTML",
                                     reply_markup=btn)
            except Exception as e:
                image = await get_input_file(book[5])
                image_id = await bot.send_photo(callback.message.chat.id, image, caption=msg, parse_mode="HTML",
                                                reply_markup=btn)
                db.update_book(image_id['photo'][-1]['file_id'], book[0])
        else:
            await bot.send_message(callback.message.chat.id, msg, reply_markup=btn)
    else:
        btn = InlineKeyboardMarkup()
        btn.add(back_cat)
        await callback.message.edit_text('This book wasn\'t found', reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("mybook"))
@dp.callback_query_handler(lambda query: query.data.startswith("backmybook"))
async def bot_echo(callback: types.CallbackQuery):
    book_id = callback.data.split("-")[1]
    book = db.select_book(id=book_id)
    book_files = db.select_book_audio(book_id=book_id)
    if book:
        image = None
        title = book[1]
        author = book[2]
        description = book[3]
        if book[5]:
            image = await get_book_photo(book[5], book[7])
            db.update_book(image, book[0])
        category = db.select_category(id=book[6])[1]
        if book_files:
            t = '\n<b>🎧 AUDIO BOOK INCLUDED</b>'
        else:
            t = ''
        msg = f"<b>{title}</b>{t}\n\nAuthor: <b>{author}</b>\nAbout book: <em>{description}</em>\nCategory: <b>{category}</b>"
        btn = read_or_listen_book(book_id)
        if callback.data.startswith("mybook2-"):
            btn.row(get_cat(book[6]))
        else:
            btn.row(my_books)
        await bot.delete_message(callback.message.chat.id, callback.message.message_id)
        if callback.data.startswith("backmybook"):
            num = int(callback.data.split("-")[2])
            if num:
                for i in range(num):
                    await bot.delete_message(callback.message.chat.id, callback.message.message_id - i - 1)
                await bot.delete_message(callback.message.chat.id, callback.message.message_id - num - 1)
        if image:
            try:
                await bot.send_photo(callback.message.chat.id, image, caption=msg, parse_mode="HTML",
                                     reply_markup=btn)
            except Exception as e:
                image = await get_input_file(book[5])
                image_id = await bot.send_photo(callback.message.chat.id, image, caption=msg, parse_mode="HTML",
                                                reply_markup=btn)
                db.update_book(image_id['photo'][-1]['file_id'], book[0])
        else:
            await bot.send_message(callback.message.chat.id, msg, parse_mode="HTML", reply_markup=btn)
    else:
        btn = InlineKeyboardMarkup()
        btn.add(back_cat)
        await callback.message.edit_text('This book wasn\'t found', reply_markup=btn)
