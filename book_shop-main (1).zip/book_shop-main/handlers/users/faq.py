from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup

from keyboards.default.start_buttons import first_buttons
from keyboards.inline.back_buttons import main_menu_faq
from keyboards.inline.faq_inline import see_answer_btn, next_question_btn, prev_question_btn, hide_answer_btn
from loader import dp, db, bot


# Echo bot
@dp.message_handler(text="📎 FAQ", state="*")
async def bot_echo(message: types.Message, state: FSMContext):
    await state.finish()
    faq_list = db.select_all_faq()
    btn = InlineKeyboardMarkup()
    if faq_list:
        indices = []
        i = 1
        for faq in faq_list[:4]:
            await message.answer(faq[1], parse_mode="HTML", reply_markup=see_answer_btn(faq[0]))
            indices.append(message.message_id + i)
            i += 1
        if len(faq_list) > 4:
            btn = next_question_btn(4, indices)
        btn.row(main_menu_faq(len(faq_list[:4])))
        await message.answer("<b>More Questions</b>", parse_mode="HTML", reply_markup=btn)
    else:
        btn.row(main_menu_faq(0))
        await message.answer("The FAQ is empty for now.", reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("next"))
async def next_question(message: types.CallbackQuery):
    faq_list = db.select_all_faq()
    index = int(message.data.split("-")[1])
    old_msg = message.data.split("-")[2]
    old_msg = old_msg.replace("[", "").replace("]", "").split(", ")
    for msg in old_msg:
        await bot.delete_message(message.message.chat.id, int(msg))
    await bot.delete_message(message.message.chat.id, message.message.message_id)
    indices = []
    i = 1
    for faq in faq_list[index:index + 4]:
        await message.message.answer(faq[1], parse_mode="HTML", reply_markup=see_answer_btn(faq[0]))
        indices.append(message.message.message_id + i)
        i += 1
    res = InlineKeyboardMarkup()
    res.insert(prev_question_btn(index - 4, indices, btn=True))
    if len(faq_list[index:]) > 4:
        res.insert(next_question_btn(index + 4, indices, btn=True))
    res.row(main_menu_faq(len(faq_list[index:index + 4])))
    await message.message.answer("<b>More Questions</b>", reply_markup=res, parse_mode="HTML")


@dp.callback_query_handler(lambda call: call.data.startswith("prev"))
async def prev_callback(message: types.CallbackQuery):
    faq_list = db.select_all_faq()
    index = int(message.data.split("-")[1])
    old_msg = message.data.split("-")[2]
    old_msg = old_msg.replace("[", "").replace("]", "").split(", ")
    for msg in old_msg:
        await bot.delete_message(message.message.chat.id, int(msg))
    await bot.delete_message(message.message.chat.id, message.message.message_id)
    indices = []
    i = 1
    for faq in faq_list[index:index + 4]:
        await message.message.answer(faq[1], parse_mode="HTML", reply_markup=see_answer_btn(faq[0]))
        indices.append(message.message.message_id + i)
        i += 1
    res = InlineKeyboardMarkup()
    if len(faq_list[:index]) >= 4:
        res.insert(prev_question_btn(index - 4, indices, btn=True))
    res.insert(next_question_btn(index + 4, indices, btn=True))
    res.row(main_menu_faq(len(faq_list[index:index + 4])))
    await message.message.answer("<b>More Questions</b>", parse_mode="HTML", reply_markup=res)


@dp.callback_query_handler(lambda call: call.data.startswith("answer"))
async def answer_question(call: types.CallbackQuery):
    ques_id = int(call.data.split("-")[1])
    answer = db.select_faq(id=ques_id)
    try:
        await call.answer(answer[2], show_alert=True)
    except Exception as e:
        await dp.bot.edit_message_text(message_id=call.message.message_id,
                                       chat_id=call.message.chat.id,
                                       text=f"{answer[1]}\n\n<b>{answer[2]}</b>",
                                       parse_mode="HTML"
                                       )
        await dp.bot.edit_message_reply_markup(message_id=call.message.message_id,
                                               chat_id=call.message.chat.id,
                                               reply_markup=hide_answer_btn(call.message.message_id, ques_id))


@dp.callback_query_handler(lambda call: call.data.startswith("hide"))
async def hide_callback(call: types.CallbackQuery):
    ques_id = call.data.split("-")[2]
    message_id = int(call.data.split("-")[1])
    question = db.select_faq(id=ques_id)
    await dp.bot.edit_message_text(message_id=message_id, chat_id=call.message.chat.id,
                                   text=question[1])
    await dp.bot.edit_message_reply_markup(message_id=message_id, chat_id=call.message.chat.id,
                                           reply_markup=see_answer_btn(ques_id))
