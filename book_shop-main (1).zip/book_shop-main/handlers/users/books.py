from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup

from keyboards.default.start_buttons import first_buttons
from keyboards.inline.back_buttons import main_menu, back_cat
from keyboards.inline.books_inline import get_categories, get_books, next_book, prev_book
from loader import dp, db, bot


# Echo bot
@dp.message_handler(text="📚 Books", state="*")
@dp.callback_query_handler(lambda query: query.data == "choose_cat")
async def bot_echo(message: types.Message, state: FSMContext):
    await state.finish()
    if isinstance(message, types.CallbackQuery):
        await message.message.delete()
        message = message.message
    categories = db.select_all_categories()
    btn = get_categories(categories)
    btn.row(main_menu)
    if categories:
        await message.answer("Choose a category:", reply_markup=btn)
    else:
        btn = InlineKeyboardMarkup()
        btn.row(main_menu)
        await message.answer("No categories found.", reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("cat-"))
async def bot_echo(callback: types.CallbackQuery):
    cat_id = callback.data.split('-')[1]
    books = db.select_books(category_id=cat_id)
    cat_name = db.select_category(id=cat_id)[1]
    msg = f"Books from category <b>{cat_name}</b>:\n\n"
    if books:
        for i, book in enumerate(books[:10], start=1):
            msg += f"{i}. {book[1]}\n"
        btns = get_books(books[:10], user_id=callback.from_user.id)
        if len(books) > 10:
            btns.row(next_book(10, cat_id))
        btns.row(back_cat)
        await callback.message.delete()
        await bot.send_message(callback.message.chat.id, msg, reply_markup=btns)
    else:
        btn = InlineKeyboardMarkup()
        btn.row(back_cat)
        await callback.message.edit_text('No books found.', reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("bnext"))
async def bot_echo(callback: types.CallbackQuery):
    cat_id = callback.data.split('-')[1]
    book_id = int(callback.data.split('-')[2])
    books = db.select_books(category_id=cat_id)
    cat_name = db.select_category(id=cat_id)[1]
    msg = f"Books from category <b>{cat_name}</b>:\n\n"
    for i, book in enumerate(books[book_id:book_id + 10], start=1):
        msg += f"{i}. {book[1]}\n"
    btns = get_books(books[book_id:book_id + 10], user_id=callback.from_user.id)
    next_prev = [prev_book(book_id - 10, cat_id)]
    if len(books[book_id:]) > 10:
        next_prev.append(next_book(book_id + 10, cat_id))
    btns.row(*next_prev)
    btns.row(back_cat)
    await callback.message.edit_text(msg, parse_mode="HTML", reply_markup=btns)


@dp.callback_query_handler(lambda query: query.data.startswith("bprev"))
async def bot_echo(callback: types.CallbackQuery):
    cat_id = callback.data.split('-')[1]
    book_id = int(callback.data.split('-')[2])
    books = db.select_books(category_id=cat_id)
    cat_name = db.select_category(id=cat_id)[1]
    msg = f"Books from category <b>{cat_name}</b>:\n\n"
    for i, book in enumerate(books[book_id:book_id + 10], start=1):
        msg += f"{i}. {book[1]}\n"
    btns = get_books(books[book_id:book_id + 10], user_id=callback.from_user.id)
    next_prev = []
    if len(books[:book_id]) >= 10:
        next_prev.append(prev_book(book_id - 10, cat_id))
    next_prev.append(next_book(book_id + 10, cat_id))
    btns.row(*next_prev)
    btns.row(back_cat)
    await callback.message.edit_text(msg, parse_mode="HTML", reply_markup=btns)
