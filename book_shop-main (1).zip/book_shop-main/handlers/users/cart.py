from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup
from random import randint
from aiogram import types
from aiogram.types import LabeledPrice

from keyboards.inline.back_buttons import main_menu, get_cat, my_cart
from keyboards.inline.cart_inline import get_cart_items
from utils.misc.product import Product
from keyboards.default.start_buttons import first_buttons
from keyboards.inline.payment_inline import buy_from_cart
from loader import dp, db, bot


# Echo bot
@dp.message_handler(text="🛒 Cart", state="*")
@dp.callback_query_handler(lambda query: query.data.startswith('backcart'))
async def bot_echo(message: types.Message, state: FSMContext):
    await state.finish()
    cart_items = db.select_cart_items(user_id=message.from_user.id)
    if isinstance(message, types.CallbackQuery):
        await message.message.delete()
        message = message.message
    msg = "Books in your cart:\n\n"
    total = 0
    list_book_id = []
    if cart_items:
        for i, item in enumerate(cart_items, start=1):
            book = db.select_book(id=item[1])
            msg += f"{i}. <b>{book[1]}</b> - <em>{book[4]} so'm</em>\n"
            total += int(book[4])
            list_book_id.append(str(item[1]))
        msg += f"\n<b>Total: {total} so'm</b>"
        btn = get_cart_items(cart_items)
        btn.row(buy_from_cart('-'.join(list_book_id)))
        btn.row(main_menu)
        await message.answer(msg, parse_mode='HTML', reply_markup=btn)
    else:
        btn = InlineKeyboardMarkup()
        btn.row(main_menu)
        await message.answer("There are no books in your cart", reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("addtocart"))
async def addtocart_callback(callback: types.CallbackQuery):
    book_id = callback.data.split("-")[1]
    book = db.select_book(id=book_id)
    book_name = book[1]
    user_id = callback.from_user.id
    db.create_cart_item(book_id, user_id)
    btn = InlineKeyboardMarkup()
    btn.row(get_cat(book[6]))
    msg = (f'You have successfully add the book <b>"{book_name}"</b> to cart, return to the list of books'
           f' to buy more or click on <b>"🛒 Cart"</b> in the Main Menu to buy this book')
    await bot.delete_message(callback.message.chat.id, callback.message.message_id)
    await bot.send_message(callback.message.chat.id, msg, parse_mode="HTML", reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith('cartbook'))
async def addtocart(callback: types.CallbackQuery):
    book_id = callback.data.split("-")[1]
    book = db.select_book(id=book_id)
    book_name = book[1]
    cat_id = book[6]
    btn = InlineKeyboardMarkup()
    btn.row(get_cat(cat_id))
    await callback.message.edit_text(f'{book_name} has been added to your cart', reply_markup=btn)


@dp.callback_query_handler(lambda query: query.data.startswith("deleteitem"))
async def cartitem_callback(callback: types.CallbackQuery):
    cartitem_id = callback.data.split("-")[1]
    db.delete_cart_item(cartitem_id)
    msg = 'This book has been deleted from your cart.'
    btn = InlineKeyboardMarkup()
    btn.row(my_cart)
    await callback.message.delete()
    await bot.send_message(callback.message.chat.id, msg, reply_markup=btn)
