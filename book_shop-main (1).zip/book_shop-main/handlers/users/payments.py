from random import randint
from aiogram import types
from aiogram.types import LabeledPrice, InlineKeyboardMarkup, InlineKeyboardButton
from keyboards.default.start_buttons import first_buttons
from keyboards.inline.back_buttons import my_books
from loader import dp, db, bot
from utils.misc.product import Product


@dp.callback_query_handler(lambda query: query.data.startswith("buynow"))
async def buynow_callback(callback: types.CallbackQuery):
    await callback.answer()
    book_id = callback.data.split("-")[1]
    book = db.select_book(id=book_id)
    book_payment = Product(
        title="Kitob sotib olish",
        description="Kitobni xarid qilish uchun quyidagi tugmani bosing",
        prices=[LabeledPrice(label=book[1], amount=int(f"{book[4]}00"))],
        start_parameter=f'{book[0]}-{callback.message.chat.id}-{randint(23, 20000)}'
    )
    payload = f"now-{book_id}"
    await bot.send_invoice(callback.message.chat.id, **book_payment.generate_invoice(), payload=payload)


@dp.callback_query_handler(lambda query: query.data.startswith('bc'))
async def buycart(callback: types.CallbackQuery):
    books = callback.data.split('-')[1:]
    await callback.answer()
    books = db.select_books_by_id(id__in=books)
    list_bookid = [str(i[0]) for i in books]
    book_payment = Product(
        title="Kitoblar sotib olish",
        description="Kitoblarni xarid qilish uchun quyidagi tugmani bosing",
        prices=[
            LabeledPrice(label=book[1], amount=int(f"{book[4]}00")) for book in books
        ],
        start_parameter=f'{books[0][0]}-{callback.message.chat.id}-{randint(23, 20000)}'
    )
    payload = f"cart-{'-'.join(list_bookid)}"
    await bot.send_invoice(callback.message.chat.id, **book_payment.generate_invoice(), payload=payload)


@dp.pre_checkout_query_handler(lambda query: query.invoice_payload.startswith("now"))
async def nowsuccess_callback(callback: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query_id=callback.id, ok=True)
    book_id = callback.invoice_payload.split("-")[1]
    book_name = db.select_book(id=book_id)[1]
    user_id = callback.from_user.id
    db.create_order(book_id, user_id)
    msg = (f'You have successfully purchased the book <b>"{book_name}"</b>, return to the list of books'
           f' to buy more or click on <b>"📚 My Books"</b> in the Main Menu to read or listen to this book')
    btn = InlineKeyboardMarkup()
    btn.add(InlineKeyboardButton('List of Books', callback_data='choose_cat'))
    btn.add(my_books)
    await bot.send_message(callback.from_user.id, msg, parse_mode='HTML', reply_markup=btn)


@dp.pre_checkout_query_handler(lambda query: query.invoice_payload.startswith('cart'))
async def checkout(callback: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query_id=callback.id, ok=True)
    books = callback.invoice_payload.split('-')[1:]
    for book in books:
        db.create_order(int(book), callback.from_user.id)
    db.clear_cart(callback.from_user.id)
    btn = InlineKeyboardMarkup()
    btn.add(InlineKeyboardButton('List of Books', callback_data='choose_cat'))
    btn.add(my_books)
    await bot.send_message(callback.from_user.id,
                           'Your order has been successfully completed! Go to <b>"📚 My Books"</b> in the Main Menu to start reading your new books!',
                           parse_mode="HTML", reply_markup=btn)
