from environs import Env

env = Env()
env.read_env()

BOT_TOKEN: str = env.str("BOT_TOKEN")
ADMINS: list = env.list("ADMINS", cast=int)
PROVIDER_TOKEN: str = env.str("PROVIDER_TOKEN")
GROUP: str = env.int("GROUP")
