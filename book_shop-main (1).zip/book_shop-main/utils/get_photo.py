
import os
from aiogram.types import InputFile
import zipfile
from data.config import ADMINS, GROUP
from loader import bot

media_dir = r'/root/book_shop_admin/media'
# media_dir = r'C:\Users\obidj\PycharmProjects\book_shop_admin\media'


async def get_book_photo(path_to_file, file_id):
    if file_id:
        return file_id
    photo_path = os.path.join(media_dir, path_to_file)
    print(photo_path, path_to_file)
    data = await bot.send_photo(GROUP, InputFile(photo_path))
    return data['photo'][-1]['file_id']


async def get_input_file(path_to_file):
    photo_path = os.path.join(media_dir, path_to_file)
    return InputFile(photo_path)


async def get_book_file(path_to_file, file_id):
    if file_id:
        return file_id
    photo_path = os.path.join(media_dir, path_to_file)
    data = await bot.send_document(GROUP, InputFile(photo_path))
    return data['document']['file_id']


async def get_book_audio(path_to_file, file_id):
    if file_id:
        return file_id
    photo_path = os.path.join(media_dir, path_to_file)
    data = await bot.send_document(GROUP, InputFile(photo_path))
    return data['audio']['file_id']
