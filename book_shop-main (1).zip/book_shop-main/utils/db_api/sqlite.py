import sqlite3


class Database:
    def __init__(self, path_to_db="main.db"):
        self.path_to_db = path_to_db

    @property
    def connection(self):
        return sqlite3.connect(self.path_to_db)

    def execute(self, sql: str, parameters: tuple = None, fetchone=False, fetchall=False, commit=False):
        if not parameters:
            parameters = ()
        connection = self.connection
        connection.set_trace_callback(logger)
        cursor = connection.cursor()
        data = None
        cursor.execute(sql, parameters)

        if commit:
            connection.commit()
        if fetchall:
            data = cursor.fetchall()
        if fetchone:
            data = cursor.fetchone()
        connection.close()
        return data

    @staticmethod
    def format_args(sql, parameters: dict):
        sql += " AND ".join([
            f"{item} = ?" for item in parameters
        ])
        return sql, tuple(parameters.values())

    def add_user(self, id: int, name: str, email: str = None, language: str = 'uz'):
        # SQL_EXAMPLE = "INSERT INTO Users(id, Name, email) VALUES(1, 'John', 'John@gmail.com')"

        sql = """
        INSERT INTO Users(id, Name, email, language) VALUES(?, ?, ?, ?)
        """
        self.execute(sql, parameters=(id, name, email, language), commit=True)

    def select_all_users(self):
        sql = """
        SELECT * FROM tg_users
        """
        return self.execute(sql, fetchall=True)

    def select_user(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM Users where id=1 AND Name='John'"
        sql = "SELECT * FROM Users WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchone=True)

    def count_users(self):
        return self.execute("SELECT COUNT(*) FROM Users;", fetchone=True)

    def update_user_email(self, email, id):
        # SQL_EXAMPLE = "UPDATE Users SET email=mail@gmail.com WHERE id=12345"

        sql = f"""
        UPDATE Users SET email=? WHERE id=?
        """
        return self.execute(sql, parameters=(email, id), commit=True)

    def delete_users(self):
        self.execute("DELETE FROM Users WHERE TRUE", commit=True)

    def select_all_faq(self):
        sql = "SELECT * FROM faq"
        return self.execute(sql, fetchall=True)

    def select_faq(self, **kwargs):
        sql = "SELECT * FROM faq WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchone=True)

    def select_all_categories(self):
        sql = "SELECT * FROM categories"
        return self.execute(sql, fetchall=True)

    def select_books(self, **kwargs):
        sql = "SELECT * FROM books WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchall=True)

    def select_all_contacts(self):
        sql = "SELECT * FROM contacts"
        return self.execute(sql, fetchall=True)

    def select_category(self, **kwargs):
        sql = "SELECT * FROM categories WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchone=True)

    def select_book(self, **kwargs):
        sql = "SELECT * FROM books WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchone=True)

    def create_order(self, book_id, user_id):
        sql = "INSERT INTO orders(book_id, user_id) VALUES (?, ?)"
        return self.execute(sql, parameters=(book_id, user_id), commit=True)

    def create_cart_item(self, book_id, user_id):
        sql = "INSERT INTO carts (book_id, user_id) VALUES (?, ?)"
        return self.execute(sql, parameters=(book_id, user_id), commit=True)

    def select_my_orders(self, **kwargs):
        sql = "SELECT * FROM orders WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchall=True)

    def select_book_files(self, **kwargs):
        sql = "SELECT * FROM book_files WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchall=True)

    def select_book_audio(self, **kwargs):
        sql = "SELECT * FROM audio WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchall=True)

    def select_cart_items(self, **kwargs):
        sql = "SELECT * FROM carts WHERE "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchall=True)

    def create_user(self, full_name, username, tg_id):
        sql = "INSERT INTO tg_users(full_name, username, tg_id) VALUES (?, ?, ?)"
        parameters = (full_name, username, tg_id)
        return self.execute(sql, parameters=parameters, commit=True)

    def clear_cart(self, user_id):
        sql = "DELETE FROM carts WHERE user_id = ?"
        parameters = (user_id,)
        return self.execute(sql, parameters=parameters, commit=True)

    def select_books_by_id(self, id__in):
        placeholders = ', '.join('?' for _ in id__in)
        sql = f"SELECT * FROM books WHERE id IN ({placeholders})"
        parameters = tuple(id__in)
        return self.execute(sql, parameters=parameters, fetchall=True)

    def update_book(self, image_id, id):
        sql = "UPDATE books SET image_id = ? WHERE id = ?"
        return self.execute(sql, parameters=(image_id, id), commit=True)

    def update_file(self, file_id, id):
        sql = "UPDATE book_files SET file_id = ? WHERE id = ?"
        return self.execute(sql, parameters=(file_id, id), commit=True)

    def update_audio(self, file_id, id):
        sql = "UPDATE audio SET file_id = ? WHERE id = ?"
        return self.execute(sql, parameters=(file_id, id), commit=True)

    def delete_cart_item(self, cart_item_id):
        sql = "DELETE FROM carts WHERE id = ?"
        return self.execute(sql, parameters=(cart_item_id,), commit=True)


def logger(statement):
    print(f"""
_____________________________________________________        
Executing: 
{statement}
_____________________________________________________
""")
